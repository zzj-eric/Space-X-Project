#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
PYTHON="${PYTHON:-python3}"
WORKERS="${WORKERS:-2}"
command -v ffmpeg >/dev/null || { echo 'ffmpeg is required.' >&2; exit 1; }
command -v ffprobe >/dev/null || { echo 'ffprobe is required.' >&2; exit 1; }
# The saved narration and word boundaries are reused without network access.
"$PYTHON" source/synthesize_narration.py
"$PYTHON" source/render_all.py --workers "$WORKERS"
"$PYTHON" source/finish_video.py --output "${1:-output}"
