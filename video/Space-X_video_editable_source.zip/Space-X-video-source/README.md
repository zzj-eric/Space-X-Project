# Space-X research video: editable source

An English narrated research film, 1920 x 1080 at 24 fps, lasting approximately 212 seconds. It contains twelve chapters with animated diagrams, recorded spatial cases, benchmark comparisons, joint-evolution ablations, capability growth, and X-SFT.

## Rebuild the supplied film

Use Python 3.10 or newer and FFmpeg with libx264, AAC, and the loudnorm filter. Install the rendering dependencies in your preferred Python environment:

```bash
python3 -m pip install -r requirements.txt
bash rebuild.sh
```

The output is written to `output/`. To choose another folder and reduce CPU usage:

```bash
WORKERS=1 bash rebuild.sh ./my_video
```

The saved MP3 narration and word-boundary metadata are included, so rebuilding the supplied film does not require a speech service or network connection. Rendering uses the CPU, not the GPU. Two scene processes run by default; each video encoder uses three CPU threads. `WORKERS` can be 1 through 4.

## Edit the content

- `source/storyboard.json`: chapter titles and narration sentences.
- `source/render_video.py`: scene composition, image placement, animation, typography, and subtitle formatting.
- `project_assets/research-data.json`: the score snapshot, ablation results, and optimization sequence used in the graphics.
- `assets/`: the Space-X logo and robot illustrations.
- `project_assets/assets/atlas/`: the original case images used by the film.
- `project_assets/assets/fonts/`: bundled typefaces and their license texts.
- `audio/`: one MP3 and one word-boundary JSONL file for each chapter.
- `source/timeline.json`: generated scene starts and frame-aligned durations.

For visual-only edits, run `bash rebuild.sh` again. The renderer uses content fingerprints to prevent reuse of stale scenes after edits. For a quick visual check without rendering the complete film:

```bash
python3 source/render_video.py --preview
```

Preview frames are written to `preview/`. Individual scenes can be rendered with `python3 source/render_video.py --scene 4` (zero-based index).

## Change or regenerate the narration

The film uses the stock synthetic male voice `en-US-AndrewNeural` at rate `+4%`; it is not a cloned voice. After editing spoken sentences, install the optional speech dependency and regenerate the changed segments:

```bash
python3 -m pip install -r requirements-voice.txt
python3 source/synthesize_narration.py
bash rebuild.sh
```

Speech regeneration uses the network and sends the narration text to the speech service. To regenerate all segments, use `--refresh-voice`. The generated timeline aligns scenes to 24 fps and synchronizes the results-panel model switch with its narrated sentence. The word boundaries also drive the on-screen captions and SRT/VTT exports.

## Output

`finish_video.py` exports an H.264/AAC MP4, standalone narration, SRT/VTT subtitles, a poster, chapter data, and the narration script. Captions are already embedded visually in the MP4. Audio is mastered toward -16 LUFS and -1.5 dBTP. Avoid enabling a second external subtitle overlay during normal playback.

This archive contains only the film's code and supporting assets. The original evaluation runs and private model configurations are not needed for rebuilding.
