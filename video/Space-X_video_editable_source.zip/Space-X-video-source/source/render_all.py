#!/usr/bin/env python3
"""Render independent scenes with a bounded CPU pool and content-aware caching."""
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
import argparse
import hashlib
import json
import os
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workers', type=int, default=2,
                        help='Concurrent CPU rendering processes (1 to 4).')
    parser.add_argument('--force', action='store_true', help='Ignore scene caches.')
    args = parser.parse_args()
    if not 1 <= args.workers <= 4:
        parser.error('--workers must be between 1 and 4')
    scenes = json.loads((ROOT / 'source/timeline.json').read_text())
    asset_root = Path(os.environ.get('SPACE_X_ASSET_ROOT', str(ROOT / 'project_assets')))
    inputs = [ROOT / 'source/render_video.py', ROOT / 'source/timeline.json']
    for directory in [ROOT / 'assets', ROOT / 'audio', asset_root]:
        inputs.extend(sorted(p for p in directory.rglob('*') if p.is_file()))
    digest = hashlib.sha256()
    for path in inputs:
        digest.update(str(path.relative_to(ROOT) if path.is_relative_to(ROOT) else path).encode())
        digest.update(path.read_bytes())
    fingerprint = digest.hexdigest()
    (ROOT / 'renders').mkdir(exist_ok=True)
    started = time.time()

    def render(i):
        scene = scenes[i]
        output = ROOT / 'renders' / f'{i:02d}_{scene["id"]}.mp4'
        log = output.with_suffix('.log')
        cache = output.with_suffix('.sha256')
        if not args.force and output.exists() and cache.exists() and cache.read_text().strip() == fingerprint:
            try:
                result = json.loads(subprocess.check_output([
                    'ffprobe', '-v', 'error', '-select_streams', 'v:0',
                    '-show_streams', '-of', 'json', str(output)], text=True))
                if int(result['streams'][0].get('nb_frames', '0')) == scene['frames']:
                    return {'scene': i, 'id': scene['id'], 'reused': True,
                            'bytes': output.stat().st_size}
            except (ValueError, KeyError, IndexError, subprocess.CalledProcessError):
                pass
        with log.open('w') as stream:
            result = subprocess.run([sys.executable, str(ROOT / 'source/render_video.py'),
                                     '--scene', str(i)], stdout=stream, stderr=subprocess.STDOUT)
        if result.returncode:
            raise RuntimeError(f'Scene {i} failed: {log.read_text()[-1500:]}')
        cache.write_text(fingerprint + '\n')
        return {'scene': i, 'id': scene['id'], 'bytes': output.stat().st_size}

    completed = []
    with ThreadPoolExecutor(max_workers=args.workers) as executor:
        futures = [executor.submit(render, i) for i in range(len(scenes))]
        for future in as_completed(futures):
            result = future.result()
            completed.append(result)
            report = {'completed': len(completed), 'total': len(scenes),
                      'elapsed_seconds': round(time.time() - started, 1),
                      'scenes': sorted(completed, key=lambda row: row['scene'])}
            (ROOT / 'render_progress.json').write_text(json.dumps(report, indent=2) + '\n')
            print('RENDER PROGRESS', result, report['elapsed_seconds'], flush=True)
    print('ALL SCENES COMPLETE', round(time.time() - started, 1), flush=True)


if __name__ == '__main__':
    main()
