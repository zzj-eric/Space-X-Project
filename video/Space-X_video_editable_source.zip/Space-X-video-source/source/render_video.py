#!/usr/bin/env python3
"""Render the narrated Space-X research film using source assets and measured data."""
from pathlib import Path
from functools import lru_cache
import argparse,bisect,json,math,os,re,subprocess,textwrap,time
import numpy as np
from PIL import Image,ImageDraw,ImageFont,ImageOps

ROOT=Path(__file__).resolve().parents[1]
SITE=Path(os.environ.get('SPACE_X_ASSET_ROOT',str(ROOT/'project_assets')))
TIMELINE=json.loads((ROOT/'source/timeline.json').read_text())
DATA=json.loads((SITE/'research-data.json').read_text())
W,H,FPS=1920,1080,24
C={'bg':'#e3edf4','ink':'#173c53','muted':'#486a7d','line':'#adc6d6','teal':'#087d86','purple':'#7358a7','blue':'#2c79a5','amber':'#a96338','white':'#f5f9fc','red':'#ad6257'}
TOTAL=sum(s['duration']for s in TIMELINE)

def ease(x):
 x=max(0,min(1,x));return 1-(1-x)**3

def progress(t,start=0,length=1):return ease((t-start)/length)

@lru_cache(maxsize=120)
def font(size,weight=500,display=False):
 f=ImageFont.truetype(str(SITE/'assets/fonts'/('space-grotesk.ttf' if display else 'manrope.ttf')),size)
 f.set_variation_by_axes([weight]);return f

def text(draw,xy,value,size=32,fill=None,weight=500,display=False,anchor=None):
 draw.text(xy,str(value),font=font(size,weight,display),fill=fill or C['ink'],anchor=anchor,spacing=6)

def text_in_box(draw,box,value,size=32,fill=None,weight=500,display=False,align='center',spacing=6):
 """Center visible glyph bounds vertically; optionally retain left alignment."""
 f=font(size,weight,display)
 bounds=draw.multiline_textbbox((0,0),str(value),font=f,spacing=spacing,align=align)
 x=box[0]-bounds[0] if align=='left' else (box[0]+box[2]-bounds[0]-bounds[2])/2
 y=(box[1]+box[3]-bounds[1]-bounds[3])/2
 draw.multiline_text((x,y),str(value),font=f,fill=fill or C['ink'],spacing=spacing,align=align)
 return (x+bounds[0],y+bounds[1],x+bounds[2],y+bounds[3])

def lines_for(value,size,width,weight=500,display=False):
 f=font(size,weight,display);lines=[]
 for para in str(value).split('\n'):
  current=''
  for word in para.split():
   candidate=(current+' '+word).strip()
   if current and f.getlength(candidate)>width:lines.append(current);current=word
   else:current=candidate
  lines.append(current)
 return lines

def paragraph(draw,xy,value,size=30,width=800,fill=None,weight=500,display=False,leading=1.35):
 y=xy[1]
 for line in lines_for(value,size,width,weight,display):text(draw,(xy[0],y),line,size,fill,weight,display);y+=int(size*leading)
 return y

def panel(draw,box,fill=None,outline=None,radius=22,width=2):draw.rounded_rectangle(tuple(map(int,box)),radius=radius,fill=fill or C['white'],outline=outline or C['line'],width=width)

def arrow(draw,p0,p1,color=None,width=4,fraction=1):
 color=color or C['teal'];p=(p0[0]+(p1[0]-p0[0])*fraction,p0[1]+(p1[1]-p0[1])*fraction);draw.line([p0,p],fill=color,width=width)
 if fraction>.98:
  a=math.atan2(p1[1]-p0[1],p1[0]-p0[0]);s=14;pts=[p1,(p1[0]-s*math.cos(a-.5),p1[1]-s*math.sin(a-.5)),(p1[0]-s*math.cos(a+.5),p1[1]-s*math.sin(a+.5))];draw.polygon(pts,fill=color)

@lru_cache(maxsize=120)
def asset(name):
 p=ROOT/'assets'/name
 if not p.exists():p=SITE/'assets/atlas'/name
 if not p.exists():p=SITE/'assets/readme'/name
 return Image.open(p).convert('RGBA')

@lru_cache(maxsize=180)
def resized_asset(name,w,h,fit,zoom):
 a=asset(name)
 if fit=='contain':return ImageOps.contain(a,(w,h),Image.Resampling.LANCZOS)
 a=ImageOps.fit(a,(max(1,int(w*zoom)),max(1,int(h*zoom))),method=Image.Resampling.LANCZOS)
 return a.crop(((a.width-w)//2,(a.height-h)//2,(a.width+w)//2,(a.height+h)//2))

def paste(im,name,box,fit='cover',zoom=1):
 x,y,w,h=map(int,box);a=resized_asset(name,w,h,fit,round(zoom,4))
 im.paste(a,(x+(w-a.width)//2,y+(h-a.height)//2),a)

def pill(draw,xy,label,color=None,size=24):
 f=font(size,600);width=f.getlength(label)+32;x,y=xy;box=(x,y,x+width,y+size+22);panel(draw,box,C['white'],color or C['line'],10);text_in_box(draw,box,label,size,color or C['teal'],600)
 return width

def headline(draw,scene):
 text(draw,(90,91),scene['chapter'].upper(),24,C['teal'],700)
 y=155
 for line in scene['title'].split('\n'):text(draw,(90,y),line,60,C['ink'],600,True);y+=70
 return y

def number(draw,xy,value,label,color=None,size=88):
 text(draw,xy,value,size,color or C['teal'],600,True);text(draw,(xy[0],xy[1]+size+6),label,25,C['muted'],500)

def foot(draw,index,local):
 text(draw,(90,1034),'SPACE-X  /  RESEARCH OVERVIEW',20,C['muted'],600)
 text(draw,(1830,1034),f'{index+1:02d} / {len(TIMELINE):02d}',20,C['muted'],500,True,anchor='ra')
 start=TIMELINE[index]['start'];p=(start+local)/TOTAL
 draw.line([(90,1066),(1830,1066)],fill=C['line'],width=3);draw.line([(90,1066),(90+1740*p,1066)],fill=C['teal'],width=4)

def base(scene,index,t):
 im=Image.new('RGB',(W,H),C['bg']);d=ImageDraw.Draw(im)
 for x in range(70,1900,64):d.line([(x,45),(x,960)],fill='#dbe7f0',width=1)
 for y in range(45,960,64):d.line([(70,y),(1870,y)],fill='#dbe7f0',width=1)
 headline(d,scene);foot(d,index,t)
 return im,d

def opening(im,d,t,duration):
 paste(im,'logo.png',(85,342,555,173),'contain')
 paragraph(d,(90,544),'Self-Evolving Spatial Agents\nWeaving Clues into Evidence Chains',42,830,C['ink'],500,True)
 pill(d,(90,744),'Self-evolution is the method',C['teal'])
 pill(d,(90,803),'Reliable evidence is the goal',C['purple'])
 paste(im,'evidence_workshop.png',(1135,337,640,515),'contain')
 names=['OBSERVATION','GEOMETRY','MEMORY','ANSWER']
 for i,n in enumerate(names):
  if t>.5+i*.8:
   x=1050+i*196;box=(x,850,x+177,903);panel(d,box,'#f3f8fb',C['line'],12);text_in_box(d,box,n,18,C['teal'],600)
   if i:arrow(d,(x-17,875),(x-3,875),C['teal'],3)

def problem(im,d,t,duration):
 names=['Missing premises','Mismatched semantics','Premature judgment'];sub=['The decisive view is absent.','A correct output, the wrong meaning.','The answer outruns its support.'];imgs=['sofa_1.webp','stool_depth_luminous.webp','telephone_detail.webp']
 for i in range(3):
  x=90+i*586;p=progress(t,.25+i*.65,1);y=350+int((1-p)*28)
  panel(d,(x,y,x+552,y+485));paste(im,imgs[i],(x+19,y+20,514,250),zoom=1+.025*t/duration)
  text(d,(x+25,y+292),names[i],34,C['ink'],600,True);paragraph(d,(x+25,y+347),sub[i],26,495,C['muted'])
  d.line([(x+24,y+455),(x+526,y+455)],fill=C['red'],width=4)
  if i==1:pill(d,(x+47,y+188),'Depth  !=  surface distance',C['red'],22)
  if i==0:d.rectangle((x+265,y+75,x+433,y+212),outline=C['amber'],width=5)
  if i==2:pill(d,(x+46,y+192),'Revisit the supporting source',C['red'],22)
 text(d,(960,883),'A tool output is not yet an evidence chain.',35,C['teal'],600,True,anchor='ma')

def loop(im,d,t,duration):
 panel(d,(95,348,765,836));panel(d,(1155,348,1825,836),outline='#b7a8cc')
 text(d,(430,375),'Execution Agent',36,C['teal'],600,True,anchor='ma');text(d,(1490,375),'Control Agent',36,C['purple'],600,True,anchor='ma')
 paste(im,'execution_robot.png',(262,429,335,246),'contain');paste(im,'control_robot.png',(1320,429,335,246),'contain')
 paragraph(d,(159,708),'Acquire, associate, and judge evidence.',27,550,C['muted'])
 paragraph(d,(1215,708),'Diagnose links. Improve the harness.',27,550,C['muted'])
 angle=t*.55;cx,cy=960,575
 for j in range(2):
  d.arc((cx-127,cy-127,cx+127,cy+127),int(math.degrees(angle)+j*180),int(math.degrees(angle)+j*180+140),fill=C['teal'] if j==0 else C['purple'],width=6)
 text_in_box(d,(cx-114,cy-105,cx+114,cy+105),'Reliable\nevidence\nchains',30,C['ink'],600,True)
 arrow(d,(762,422),(1153,422),C['purple'],4,progress(t,1,1));text(d,(960,371),'Traces + feedback',22,C['purple'],600,anchor='ma')
 arrow(d,(1155,795),(765,795),C['teal'],4,progress(t,4,1));text(d,(960,835),'Retained improvements',22,C['teal'],600,anchor='ma')
 labels=['TOOLS','INTERFACES','SKILLS','MEMORY','RULES'];x=420
 for i,n in enumerate(labels):x+=pill(d,(x,871),n,C['purple'] if i%2 else C['teal'],18)+14

def chain(im,d,t,duration):
 titles=['Acquire','Associate','Judge'];copy=['Question-relevant observations','Objects + sources + frames','Evidence supports each claim'];icons=['mural_3.webp','stool_mask_focus.webp','telephone_detail.webp']
 for i in range(3):
  x=92+i*595;panel(d,(x,360,x+548,760));paste(im,icons[i],(x+20,380,508,203),zoom=1+.02*t/duration)
  text(d,(x+24,609),titles[i],45,C['teal'],600,True);paragraph(d,(x+24,671),copy[i],26,499,C['muted'])
  if i<2:arrow(d,(x+552,554),(x+586,554),C['teal'],5,progress(t,2+i*2,1))
 fields=['Working','Observation','Spatial','Episodic','Procedural']
 panel(d,(91,812,1830,924),'#d8e8ef',C['line'],18)
 text_in_box(d,(116,812,330,924),'MEMORY',21,C['muted'],700,align='left')
 for i,n in enumerate(fields):
  cx=475+i*285
  text_in_box(d,(cx-130,812,cx+130,924),n,25,C['ink'],600)

def metric(im,d,t,duration):
 source=t<duration*.35
 for i,obj in enumerate(['stool','toilet']):
  x=91+i*552;panel(d,(x,350,x+522,836));paste(im,obj+('_rgb.webp' if source else '_mask_focus.webp'),(x+17,369,488,282),zoom=1+.025*t/duration)
  text(d,(x+23,676),'Stool' if i==0 else 'Toilet',35,C['ink'],600,True)
  if not source:paste(im,obj+'_depth_luminous.webp',(x+262,679,239,136))
  text(d,(x+23,735),'Source-bound\nobject region',25,C['muted'])
 panel(d,(1236,350,1830,836),'#eef5f8',C['teal'],20)
 text(d,(1280,400),'CLOSEST SURFACES',24,C['teal'],700)
 number(d,(1280,495),'0.86 m','Source-supported answer',C['teal'],100)
 paragraph(d,(1280,710),'Objects + geometry\n+ requested endpoints',29,505,C['muted'])
 if t>duration*.3:arrow(d,(1138,585),(1221,585),C['teal'],6,progress(t,duration*.3,1))
 text(d,(90,888),'Geometry is useful only when its operands and meaning are correct.',31,C['ink'],500,True)

def viewpoint(im,d,t,duration):
 for i,name in enumerate(['mural_1.webp','mural_3.webp']):
  x=91+i*552;panel(d,(x,350,x+522,832));paste(im,name,(x+18,369,486,336),zoom=1+.02*t/duration)
  text(d,(x+25,734),'Requested camera' if i==0 else 'Target source view',30,C['ink'],600,True)
  if i==1:d.rectangle((x+85,458,x+453,600),outline=C['teal'],width=5)
 panel(d,(1236,350,1830,832),'#edf5f9',C['line'])
 cx,cy=1520,564;arrow(d,(cx,cy),(cx,414),C['muted'],4);arrow(d,(cx,cy),(1762,cy),C['muted'],4)
 text(d,(cx+12,414),'+Z / forward',24,C['muted']);text(d,(1770,cy+4),'X',23,C['muted'])
 end=(1375,663);arrow(d,(cx,cy),end,C['teal'],6,progress(t,4,2));d.ellipse((end[0]-12,end[1]-12,end[0]+12,end[1]+12),fill=C['teal'])
 text(d,(1280,720),'Behind',70,C['teal'],600,True);text(d,(90,881),'Target identity -> shared geometry -> requested reference frame',30,C['ink'],500,True)

def memory(im,d,t,duration):
 roles=['Working','Observation','Spatial','Episodic','Procedural'];cols=[C['teal'],C['blue'],C['purple'],C['amber'],C['teal']]
 for i,r in enumerate(roles):
  x=91+i*354;panel(d,(x,349,x+331,447),'#f4f8fb',cols[i],15);text(d,(x+165,379),r,30,cols[i],600,True,anchor='ma')
 for i,n in enumerate(['monitors_partial.webp','monitors_pair.webp','monitors_another_view.webp']):
  x=91+i*425;panel(d,(x,495,x+394,814));paste(im,n,(x+14,511,366,244),zoom=1+.02*t/duration);text(d,(x+21,771),['Partial view','Joint visibility','Another sighting'][i],23,C['muted'])
 panel(d,(1397,495,1830,814),C['white'],C['teal'])
 number(d,(1440,532),'8 -> 2','sightings -> instances',C['teal'],69)
 for i in range(8):
  x=1453+(i%4)*87;y=708+(i//4)*46;d.ellipse((x,y,x+22,y+22),fill=C['teal'] if i<5 else C['purple'])
 text(d,(91,885),'Preserve identity across observations, not just a list of detections.',31,C['ink'],500,True)

def results(im,d,t,duration):
 names=['ViewSpatial','SPAR','MMSI','VSI'];keys=['viewspatial','spar','mmsi','vsi'];switch=TIMELINE[7]['visualSwitch'];model='gpt-6-sol' if t<switch else 'gemini-3.8-flash';label='GPT-6-sol' if model=='gpt-6-sol' else 'Gemini-3.8-Flash';pill(d,(90,305),label,C['purple'],24)
 for i,(key,name) in enumerate(zip(keys,names)):
  x=91+i*443;pair=DATA['pairs'][model][key];a,b=pair['baseline']['score'],pair['spacex']['score'];col=[C['blue'],C['purple'],C['teal'],C['amber']][i]
  panel(d,(x,380,x+417,848));text(d,(x+25,407),name,35,C['ink'],600,True);text(d,(x+25,466),f'+{pair["relativeGain"]:.2f}%',58,col,600,True);text(d,(x+25,537),'relative improvement',22,C['muted'])
  lo=max(0,math.floor((min(a,b)-4)/5)*5);hi=min(100,math.ceil((max(a,b)+4)/5)*5)
  def y(v):return 737-(v-lo)/(hi-lo)*130
  for v in [lo,(lo+hi)/2,hi]:
   d.line([(x+64,y(v)),(x+374,y(v))],fill=C['line'],width=1);text(d,(x+49,y(v)-10),f'{v:g}',18,C['muted'],anchor='ra')
  for vx,vy in [(x+96,y(a)),(x+342,y(b))]:d.ellipse((vx-7,vy-7,vx+7,vy+7),fill=col if vx>x+200 else C['white'],outline=col,width=2)
  phase=t if model=='gpt-6-sol' else t-switch
  arrow(d,(x+96,y(a)),(x+342,y(b)),col,5,progress(phase,.2+i*.15,1.5))
  text(d,(x+32,784),f'{a:.2f}  ->  {b:.2f}',31,col,600,True)
 text(d,(91,892),'Four base models improve.  VSI uses 10 initial frames.',31,C['ink'],500,True)

def ablation(im,d,t,duration):
 rows=DATA['experiments']['joint'];names=['Initial','Tools only','Rules only','Joint evolution'];x0=755;scale=10.8
 for i,(name,row) in enumerate(zip(names,rows)):
  y=375+i*117;v=row['scores'][0];col=C['teal'] if i==3 else '#8daaba'
  text(d,(95,y+17),name,34,C['ink'],600,True);d.rounded_rectangle((x0,y+14,x0+100*scale,y+77),radius=10,fill='#cedfe9')
  width=v*scale*progress(t,.3+i*.25,1.8);d.rounded_rectangle((x0,y+14,x0+max(width,1),y+77),radius=10,fill=col)
  text(d,(x0+v*scale+20,y+22),f'{v:.2f}',32,C['teal'] if i==3 else C['muted'],600,True)
 text(d,(95,873),'ViewSpatial  |  Joint evolution: +11.84 points over tools alone',34,C['teal'],600,True)
 for v in [0,50,100]:text(d,(x0+v*scale,855),str(v),20,C['muted'],anchor='ma')

def growth(im,d,t,duration):
 ev=DATA['evolution'];panel(d,(91,354,1343,877));x0,x1,y0,y1=185,1300,823,433
 stage_colors=['#e5edf6','#ece7f2','#e1efef','#eeeadd'];boundaries=[0,130,276,445,575]
 for i in range(4):d.rectangle((x0+(x1-x0)*boundaries[i]/575,y1,x0+(x1-x0)*boundaries[i+1]/575,y0),fill=stage_colors[i])
 for v in [50,60,70,80]:y=y0-(v-50)/30*(y0-y1);d.line([(x0,y),(x1,y)],fill=C['line'],width=1);text(d,(x0-18,y-12),str(v),21,C['muted'],anchor='ra')
 for v in [0,130,276,445,575]:x=x0+v/575*(x1-x0);text(d,(x,y0+14),str(v),18,C['muted'],anchor='ma')
 f=progress(t,1,duration*.72);pos=f*575
 for key,name,color in [('viewspatial','ViewSpatial',C['teal']),('spar','SPAR',C['purple'])]:
  points=[(x0+s['position']/575*(x1-x0),y0-(s[key]-50)/30*(y0-y1))for s in ev['scores']if s['position']<=pos]
  if len(points)>1:d.line(points,fill=color,width=5)
  for x,y in points:d.ellipse((x-5,y-5,x+5,y+5),fill=color)
  text(d,(205 if key=='viewspatial' else 470,386),name,25,color,600)
 text(d,(1384,379),'575',96,C['teal'],600,True);text(d,(1390,488),'optimization candidates',25,C['muted'])
 for i,c in enumerate(ev['categories']):
  text(d,(1390,554+i*62),c['name'].replace('Evidence links & delivery','Evidence links').replace('Control & integration','Control / integration'),22,c['color'],600);text(d,(1815,554+i*62),str(c['final']),25,c['color'],600,True,anchor='ra')
 text(d,(91,880),'Measured at ten uniformly spaced checkpoints.',28,C['muted'])

def transfer(im,d,t,duration):
 panel(d,(91,350,607,850),'#e5edf7',C['line']);paste(im,'evidence_workshop.png',(136,389,425,285),'contain');text(d,(135,706),'Inherited Space-X',37,C['teal'],600,True);text(d,(135,771),'Reuse the original data',27,C['muted'])
 arrow(d,(625,587),(878,587),C['purple'],6,progress(t,1,1.5));d.ellipse((677,491,828,642),fill='#e8e1f0',outline=C['purple'],width=3);text(d,(752,518),'15',57,C['purple'],600,True,anchor='ma');text(d,(752,586),'iterations',20,C['purple'],600,anchor='ma')
 rows=DATA['experiments']['adaptation']
 for i,row in enumerate(rows):
  y=349+i*169;panel(d,(908,y,1830,y+146),C['white'],C['line'],17);text(d,(943,y+25),row['label'],29,C['ink'],600,True);text(d,(943,y+82),'ViewSpatial',24,C['muted']);text(d,(1430,y+48),f'{row["before"][0]:.2f} -> {row["after"][0]:.2f}',40,C['purple'],600,True)
 text(d,(91,906),'Transfer provides the starting point. Self-evolution refines the fit.',30,C['ink'],500,True)

def closing(im,d,t,duration):
 paste(im,'logo.png',(94,375,614,184),'contain');paragraph(d,(99,629),'A harness is more than a toolbox.\nIts value lies in coordinated evidence.',42,910,C['ink'],500,True)
 paste(im,'dual_agents.png',(1138,368,668,407),'contain')
 labels=['TOOLS','MEMORY','EVIDENCE','ANSWERS']
 for i,label in enumerate(labels):
  x=142+i*420;pill(d,(x,854),label,C['teal'] if i%2==0 else C['purple'],24)
  if i<3:arrow(d,(x+210,878),(x+370,878),C['line'],3)

SCENE_FUNCTIONS={'opening':opening,'problem':problem,'loop':loop,'chain':chain,'metric':metric,'viewpoint':viewpoint,'memory':memory,'results':results,'ablation':ablation,'growth':growth,'transfer':transfer,'closing':closing}


def captions(scene,index):
 meta=[json.loads(x) for x in (ROOT/scene['audio']).with_suffix('.jsonl').read_text().splitlines() if x.strip()]
 meta=[m for m in meta if m.get('type')=='WordBoundary']
 words=' '.join(scene['sentences']).split()
 normalize=lambda s:re.sub(r'[^a-z0-9]','',s.lower())
 assert [normalize(x['text']) for x in meta]==[normalize(x) for x in words], scene['id']
 entries=[];group=[]
 for raw,word in zip(meta,words):
  item={**raw,'text':word}
  if group and (len(' '.join(x['text'] for x in group))+len(word)>82 or (item['offset']-group[0]['offset'])/1e7>5.1):
   entries.append(group);group=[]
  group.append(item)
  if word.endswith(('.', '?', '!')):entries.append(group);group=[]
 if group:entries.append(group)
 cues=[]
 for words in entries:
  start=words[0]['offset']/1e7+scene['leadIn'];end=(words[-1]['offset']+words[-1]['duration'])/1e7+scene['leadIn']+.17
  wording=' '.join(x['text'] for x in words)
  for a,b in [('Space X','Space-X'),('View Spatial','ViewSpatial'),('G P T six sol','GPT-6-sol'),('X S F T','X-SFT')]:wording=wording.replace(a,b)
  cues.append({'start':start,'end':min(end,scene['duration']-.2),'text':wording})
 for i,cue in enumerate(cues[:-1]):cue['end']=min(cue['end'],cues[i+1]['start'])
 return cues

ALL_CUES=[captions(scene,i)for i,scene in enumerate(TIMELINE)]

def frame(index,t,subtitle=True):
 scene=TIMELINE[index];im,d=base(scene,index,t);SCENE_FUNCTIONS[scene['id']](im,d,t,scene['duration'])
 if subtitle:
  active=next((c for c in ALL_CUES[index] if c['start']<=t<c['end']),None)
  if active:
   lines=lines_for(active['text'],31,1630,500);h=len(lines)*37+20;panel(d,(115,1020-h,1805,1020),'#f5f9fc','#b4cbd8',14)
   assert len(lines)<=2
   for i,line in enumerate(lines):text(d,(960,1029-h+i*37),line,31,C['ink'],500,anchor='ma')
 # Dip through the shared blue-gray canvas between chapters, without rescaling text.
 fade=min(1,t/.35,(scene['duration']-t)/.4)
 if fade<1:im=Image.blend(Image.new('RGB',(W,H),C['bg']),im,max(0,fade))
 return im

def render_scene(index,fps=FPS):
 scene=TIMELINE[index];out=ROOT/'renders'/f'{index:02d}_{scene["id"]}.mp4';out.parent.mkdir(exist_ok=True)
 n=int(scene.get('frames',round(scene['duration']*fps)));cmd=['ffmpeg','-y','-loglevel','error','-f','rawvideo','-vcodec','rawvideo','-s',f'{W}x{H}','-pix_fmt','rgb24','-r',str(fps),'-i','-','-an','-c:v','libx264','-preset','veryfast','-crf','20','-pix_fmt','yuv420p','-threads','3',str(out)]
 proc=subprocess.Popen(cmd,stdin=subprocess.PIPE)
 start=time.time()
 try:
  for f in range(n):proc.stdin.write(frame(index,min(f/fps,scene['duration']-.001)).tobytes())
 finally:proc.stdin.close()
 if proc.wait():raise RuntimeError('ffmpeg rendering failed')
 print('RENDERED',index,scene['id'],n,'frames',round(time.time()-start,1),'seconds',flush=True)
 return out

def main():
 p=argparse.ArgumentParser();p.add_argument('--scene',type=int);p.add_argument('--preview',action='store_true');a=p.parse_args()
 if a.preview:
  target=ROOT/'preview';target.mkdir(exist_ok=True)
  for i,s in enumerate(TIMELINE):frame(i,s['duration']*.64).save(target/f'{i:02d}_{s["id"]}.png')
  print('Preview frames rendered')
 elif a.scene is not None:render_scene(a.scene)
 else:
  for i in range(len(TIMELINE)):render_scene(i)
if __name__=='__main__':main()
