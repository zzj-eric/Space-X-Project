#!/usr/bin/env python3
"""Assemble the narration, captions, chapters, and rendered research-video scenes."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import argparse, importlib.util, json, math, re, subprocess

ROOT=Path(__file__).resolve().parents[1]
TITLE='Space-X: Self-Evolving Spatial Agents Weaving Clues into Evidence Chains'

def run(args):
    return subprocess.run(args,check=True,capture_output=True,text=True)

def clock(seconds,decimal=','):
    ms=round(seconds*1000)
    hours,ms=divmod(ms,3600000);minutes,ms=divmod(ms,60000);secs,ms=divmod(ms,1000)
    return f'{hours:02d}:{minutes:02d}:{secs:02d}{decimal}{ms:03d}'

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,default=ROOT/'output')
    args=parser.parse_args();out=args.output.resolve();out.mkdir(parents=True,exist_ok=True)
    timeline=json.loads((ROOT/'source/timeline.json').read_text())
    build=ROOT/'assembly';build.mkdir(exist_ok=True)
    duration=sum(s['duration'] for s in timeline)
    fps=24
    for s in timeline:
        assert math.isclose(s['frames']/fps,s['duration'],abs_tol=1e-8)
        assert s['leadIn']+s['speechDuration']<s['duration']
    # Each audio block is padded to exactly the corresponding scene frame count.
    def prepare_audio(pair):
        i,s=pair;wav=build/f'{i:02d}.wav';samples=s['frames']*2000
        # atrim uses its input rate; enforce 48 kHz before padding/trimming.
        run(['ffmpeg','-y','-loglevel','error','-i',str(ROOT/s['audio']),
             '-af',f'aresample=48000,adelay=delays=450:all=1,apad,atrim=end_sample={samples}',
             '-ar','48000','-ac','2','-c:a','pcm_s16le',str(wav)])
        return wav
    with ThreadPoolExecutor(max_workers=4) as pool:wavs=list(pool.map(prepare_audio,enumerate(timeline)))
    audio_list=build/'audio_concat.txt';audio_list.write_text('\n'.join(f"file '{p.as_posix()}'" for p in wavs)+'\n')
    raw=build/'narration_unmastered.wav'
    run(['ffmpeg','-y','-loglevel','error','-f','concat','-safe','0','-i',str(audio_list),'-c','copy',str(raw)])
    measure=run(['ffmpeg','-hide_banner','-i',str(raw),'-af','loudnorm=I=-16:TP=-1.5:LRA=11:print_format=json','-f','null','-'])
    stats=json.loads(measure.stderr[measure.stderr.rfind('{'):])
    (build/'narration_loudness_before.json').write_text(json.dumps(stats,indent=2)+'\n')
    mastered=build/'narration_master.wav'
    settings=f'loudnorm=I=-16:TP=-1.5:LRA=11:measured_I={stats["input_i"]}:measured_LRA={stats["input_lra"]}:measured_TP={stats["input_tp"]}:measured_thresh={stats["input_thresh"]}:offset={stats["target_offset"]}:linear=true:print_format=summary'
    run(['ffmpeg','-y','-loglevel','error','-i',str(raw),'-af',settings,'-ar','48000','-ac','2','-c:a','pcm_s16le',str(mastered)])
    narration=out/'Space-X_narration_en.m4a'
    run(['ffmpeg','-y','-loglevel','error','-i',str(mastered),'-c:a','aac','-b:a','192k','-metadata','language=eng','-metadata','title=Space-X English narration',str(narration)])
    # Export exactly the caption text/timings burned into the image frames.
    spec=importlib.util.spec_from_file_location('render_video',ROOT/'source/render_video.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    cues=[]
    for s,local in zip(timeline,module.ALL_CUES):
        for cue in local:cues.append({'start':s['start']+cue['start'],'end':s['start']+cue['end'],'text':cue['text']})
    for previous,current in zip(cues,cues[1:]):assert previous['end']<=current['start']+1e-7
    (out/'Space-X_research_overview_en.srt').write_text('\n\n'.join(f'{i+1}\n{clock(c["start"])} --> {clock(c["end"])}\n{c["text"]}' for i,c in enumerate(cues))+'\n',encoding='utf-8')
    (out/'Space-X_research_overview_en.vtt').write_text('WEBVTT\n\n'+'\n\n'.join(f'{clock(c["start"],".")} --> {clock(c["end"],".")}\n{c["text"]}' for c in cues)+'\n',encoding='utf-8')
    meta=build/'chapters.ffmetadata'
    metadata=[';FFMETADATA1',f'title={TITLE}','comment=English research overview with synthetic narration and recorded research evidence.']
    for scene in timeline:
        title=scene['chapter'].replace('=','\\=').replace(';','\\;').replace('#','\\#')
        metadata += ['[CHAPTER]','TIMEBASE=1/1000',f'START={round(scene["start"]*1000)}',f'END={round((scene["start"]+scene["duration"])*1000)}',f'title={title}']
    meta.write_text('\n'.join(metadata)+'\n')
    video_list=build/'video_concat.txt'
    scenes=[ROOT/'renders'/f'{i:02d}_{s["id"]}.mp4' for i,s in enumerate(timeline)]
    assert all(p.is_file() for p in scenes)
    video_list.write_text('\n'.join(f"file '{p.as_posix()}'" for p in scenes)+'\n')
    output=out/'Space-X_research_overview_en.mp4'
    run(['ffmpeg','-y','-loglevel','error','-f','concat','-safe','0','-i',str(video_list),'-i',str(mastered),'-f','ffmetadata','-i',str(meta),
         '-map','0:v:0','-map','1:a:0','-map_metadata','2','-map_chapters','2','-c:v','copy','-c:a','aac','-b:a','192k',
         '-metadata:s:a:0','language=eng','-movflags','+faststart','-t',f'{duration:.9f}',str(output)])
    # A poster and compact storyboard help review the content without opening the editor.
    module.frame(0,6.0,subtitle=False).save(out/'Space-X_video_poster.jpg',quality=94)
    text=['# Space-X: English research overview','',f'Duration: {clock(round(duration),".")[:-4]} | 1920 x 1080 | 24 fps','',
          f"Narration: standard American English male neural voice ({timeline[0]['voice']}).",'']
    for scene in timeline:
        text += [f'## {clock(scene["start"],".")[:-4]} - {scene["chapter"]}','',
                 '**On screen:** '+scene['title'].replace('\n',' '),'',
                 ' '.join(scene['sentences']).replace('Space X','Space-X').replace('View Spatial','ViewSpatial').replace('G P T six sol','GPT-6-sol').replace('X S F T','X-SFT'),'']
    (out/'narration_and_storyboard_en.md').write_text('\n'.join(text)+'\n')
    chapters=[{'title':s['chapter'],'start':s['start'],'end':s['start']+s['duration']} for s in timeline]
    (out/'chapters.json').write_text(json.dumps(chapters,indent=2)+'\n')
    (out/'chapters.js').write_text('window.SPACE_X_VIDEO_CHAPTERS = '+json.dumps(chapters,separators=(',',':'))+';\n')
    summary={'duration_seconds':duration,'scene_count':len(timeline),'frame_count':sum(s['frames'] for s in timeline),'caption_cues':len(cues),
             'resolution':[1920,1080],'fps':fps,'voice':timeline[0]['voice'],'voice_gender':'Male','speech_rate':timeline[0]['rate'],
             'loudness_target_lufs':-16,'true_peak_target_dbtp':-1.5,'video':output.name,'audio':narration.name,'gpu_used':False}
    (out/'production_manifest.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary,indent=2));print('VIDEO',output,output.stat().st_size,'bytes')

if __name__=='__main__':main()
