#!/usr/bin/env python3
"""Generate narration as needed, then rebuild the frame-aligned scene timeline."""
from pathlib import Path
import argparse
import asyncio
import json
import math
import re
import subprocess

ROOT = Path(__file__).resolve().parents[1]
VOICE = 'en-US-AndrewNeural'
RATE = '+4%'
FPS = 24
LEAD_IN = 0.45


def tokens(text):
    return [re.sub(r'[^a-z0-9]', '', word.lower()) for word in text.split()]


def word_boundaries(path):
    return [item for line in path.read_text().splitlines() if line.strip()
            for item in [json.loads(line)] if item.get('type') == 'WordBoundary']


def audio_matches(scene, audio, metadata):
    if not audio.is_file() or audio.stat().st_size < 5000 or not metadata.is_file():
        return False
    try:
        observed = [tokens(item['text'])[0] for item in word_boundaries(metadata)]
        return observed == tokens(' '.join(scene['sentences']))
    except (ValueError, KeyError, IndexError):
        return False


async def generate(scene, index, semaphore, refresh):
    audio = ROOT / 'audio' / f'{index:02d}_{scene["id"]}.mp3'
    metadata = audio.with_suffix('.jsonl')
    receipt = audio.with_suffix('.voice.json')
    expected = {'voice': VOICE, 'rate': RATE, 'text': ' '.join(scene['sentences'])}
    same_voice = receipt.is_file() and json.loads(receipt.read_text()) == expected
    if not refresh and same_voice and audio_matches(scene, audio, metadata):
        return
    # Rebuilding with the saved voice files is fully offline.
    try:
        import edge_tts
    except ImportError as exc:
        raise RuntimeError('Voice generation requires requirements-voice.txt.') from exc
    for attempt in range(3):
        try:
            async with semaphore:
                client = edge_tts.Communicate(
                    ' '.join(scene['sentences']), voice=VOICE, rate=RATE,
                    boundary='WordBoundary')
                temp_audio = audio.with_suffix('.pending.mp3')
                temp_metadata = metadata.with_suffix('.pending.jsonl')
                await asyncio.wait_for(
                    client.save(str(temp_audio), str(temp_metadata)), timeout=110)
                if not audio_matches(scene, temp_audio, temp_metadata):
                    raise RuntimeError(f'Voice alignment mismatch: {scene["id"]}')
                temp_audio.replace(audio)
                temp_metadata.replace(metadata)
                receipt.write_text(json.dumps(expected, indent=2) + '\n')
                print('VOICE', index, scene['id'], audio.stat().st_size, flush=True)
                return
        except Exception as exc:
            if attempt == 2:
                raise
            print('RETRY', index, type(exc).__name__, flush=True)
            await asyncio.sleep(3 * (attempt + 1))


async def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--refresh-voice', action='store_true',
                        help='Regenerate all voice files; requires network access.')
    args = parser.parse_args()
    scenes = json.loads((ROOT / 'source/storyboard.json').read_text())
    (ROOT / 'audio').mkdir(exist_ok=True)
    semaphore = asyncio.Semaphore(3)
    await asyncio.gather(*(generate(scene, i, semaphore, args.refresh_voice)
                           for i, scene in enumerate(scenes)))
    timeline = []
    start = 0
    for i, scene in enumerate(scenes):
        audio = ROOT / 'audio' / f'{i:02d}_{scene["id"]}.mp3'
        duration = float(subprocess.check_output([
            'ffprobe', '-v', 'error', '-show_entries', 'format=duration',
            '-of', 'default=noprint_wrappers=1:nokey=1', str(audio)], text=True))
        frames = math.ceil((duration + 1.1) * FPS)
        item = {**scene, 'start': start, 'audio': str(audio.relative_to(ROOT)),
                'speechDuration': duration, 'duration': frames / FPS,
                'voice': VOICE, 'rate': RATE, 'leadIn': LEAD_IN, 'frames': frames}
        if scene['id'] == 'results':
            # Switch score panels when narration introduces the second model.
            word_index = sum(len(sentence.split()) for sentence in scene['sentences'][:2])
            item['visualSwitch'] = (
                word_boundaries(audio.with_suffix('.jsonl'))[word_index]['offset'] / 1e7
                + LEAD_IN)
        timeline.append(item)
        start += item['duration']
    (ROOT / 'source/timeline.json').write_text(json.dumps(timeline, indent=2) + '\n')
    print('DURATION', start, 'seconds', flush=True)


if __name__ == '__main__':
    asyncio.run(main())
